/**
* main page object containing all methods, selectors and functionality
* that is shared across all page objects
*/
module.exports = class Page {
    /**
    * Opens a sub page of the page
    * @param path path of the sub page (e.g. /path/to/page.html)
    */

    initialize(path) {
        this.open(path);
    }
    
    cleanup() {
        // Test cleanup code goes here
        // For example, deleting test data, logging out, etc.
        this.close();
    }

    open (path) {
        browser.maximizeWindow();
        return browser.url(`https://www.securian.com/${path}`)
    }
    close(){
        browser.closeWindow();
    }
}
