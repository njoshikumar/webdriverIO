const Page = require('./page');

const errorMessages=require('../testdata/errorMessages.json');

/**
 * sub page containing specific selectors and methods for a specific page
 */
class DefaultCalculatorValues extends Page {
    
    get formDefaultValues(){
        return $('#default-values-modal');
    }

    get inputadditionalIncome () {
        return $('//div[@id="default-values-modal"]//input[@id="additional-income"]');
    }   
    get inputRetirementDuration () {
        return $('//div[@id="default-values-modal"]//input[@id="retirement-duration-age"');
    }
    get rdbIncludeInflation () {        
        return $('//div[@id="default-values-modal"]//input[@id="include-inflation"');
    }
    get rdbExcludeInflation () {        
        return $('//div[@id="default-values-modal"]//input[@id="exclude-inflation"');
    }
    get inputRetirementAnnualIncome () {        
        return $('//div[@id="default-values-modal"]//input[@id="retirement-annual-income"]');
    }
    get inputPreRetirementROI () {        
        return $('//div[@id="default-values-modal"]//input[@id="pre-retirement-roi"]');
    }
    get inputPostRetirementROI () {        
        return $('//div[@id="default-values-modal"]//input[@id="post-retirement-roi"]');
    }
    get btnSaveChanges () {
        return $('//button[contains(text(), "Save changes")]');
    }
    get btnCancel () {
        return $('//button[contains(text(), "Cancel")]');
    }

    async EnterAdditionalIncome(otherIncome){
        // const element =browser.findElement('#additional-income');
        // element.setValue('50000');
        // await browser.$('#additional-income').setValue('50000');
        //await browser.setValue('#additional-income', '50000');
        await this.inputadditionalIncome.setValue(otherIncome);
    }
    async EnterHowManyYearYouNeedRetirementIncome(retirementDuration){
        await this.inputRetirementDuration.click
        await this.inputRetirementDuration.setValue(retirementDuration);
    }
    async IncreaseIncomeWithInflamation(value){
        if(value)
        {
            await this.rdbIncludeInflation.click();
        }
        else
        {
            await this.rdbExcludeInflation.click();
        }
    }
    async EnterFinalAnnaulIncomeNeededEachYear(FinalIncome){
        await this.inputRetirementAnnualIncome.setValue(FinalIncome);
    }
    async EnterPostRetirementROI(postRetirementROI){
        await this.inputPostRetirementROI.setValue(postRetirementROI);
    }
    async EnterPreRetirementROI(preRetirementROI){
        await this.inputPreRetirementROI.setValue(preRetirementROI);
    }
    async ClickSaveChanges(){
        await this.btnSaveChanges.click();
    }
    async ClickCancel(){
        await this.btnCancel.click();
    }

    async UpdateDefaultCalculatorValue(testData){
        await this.EnterAdditionalIncome(testData.additionalIncome);
        await this.EnterHowManyYearYouNeedRetirementIncome(testData.retirementDuration);
        await this.IncreaseIncomeWithInflamation(testData.postRetirementIncomeIncrease);
        await this.EnterFinalAnnaulIncomeNeededEachYear(testData.percentOfFinalIncomeDesired)
        await this.EnterPreRetirementROI(testData.preRetirementInvestmentReturn);
        await this.EnterPostRetirementROI(testData.postRetirementInvestmentReturn);
    }

}
module.exports = new DefaultCalculatorValues();