const Page = require('./page');

const errorMessages=require('../testdata/errorMessages.json');

/**
 * sub page containing specific selectors and methods for a specific page
 */
class RetirementCalculator extends Page {
    
    get inputCurrentAge () {
        return $('#current-age');
    }   

    get inputRetirementAge () {
        return $('#retirement-age');
    }

    get inputCurrentIncome () {
        return $('#current-income');
    }
    get inputSpouceIncome () {
        return $('#spouse-income');
    }
    get inputCurrentRetirementBalance(){
        return $('#current-total-savings');
    }    
    get inputCurrentlySaving(){
        return $('#current-annual-savings');
    }
    get inputRateOfIncreaseInSavings(){
        return $('#savings-increase-rate');
    }
    get rdbSocialBenifit_Yes(){
        return $('#yes-social-benefits')
    }
    get rdbSocialBenifit_No(){
        return $('#no-social-benefits')
    }
    get rdbMaritalStatus_Single(){
        return $('#single');
    }
    get rdbMaritalStatus_Married(){
        return $('#married');
    }
    get inputSocialSecurityOverrideAmount(){
        return $('#social-security-override');
    }
    get linkAdjustDefaultValues(){
        return $('//a[contains(text(),"Adjust default values")]');
    }
    get btnCalculate () {
        return $('//button[contains(text(), "Calculate")]');
    }
    get btnClearForm () {
        return $('//button[contains(text(), "Clear form")]');
    }
    get lblAllRequiredFields(){
        return $('#calculator-input-alert-desc');
    }
    get resultsChart(){
        return $('#results-chart');
    }
    
    async EnterCurrentAge(currentAge){
        await this.inputCurrentAge.setValue(currentAge);
    }
    async EnterRetirementAge(retirementAge){
        await this.inputRetirementAge.setValue(retirementAge);
    }
    async EnterCurrentAnnaulIncome(currentAnnualIncome){
        await this.inputCurrentIncome.click();
        await this.inputCurrentIncome.setValue(currentAnnualIncome);
    }
    async EnterSpouseAnnualIncome(spouseAnnualIncome){
        await this.inputSpouceIncome.setValue(spouseAnnualIncome);
    }
    async EnterCurrentRetirementSavings(currentRetirementSavings){
        await this.inputCurrentRetirementBalance.click();
        await this.inputCurrentRetirementBalance.setValue(currentRetirementSavings);
    }
    async EnterCurrentlySavingEachYear(currentRetirementContribution){
        await this.inputCurrentlySaving.setValue(currentRetirementContribution);
    }
    async EnterIncreaseInSavingsEachYear(annualRetirementContributionIncrease){
        await this.inputRateOfIncreaseInSavings.setValue(annualRetirementContributionIncrease);
    }

    async ClickOnCalculateButton(){
        await this.btnCalculate.click();
    }
    async ClickOnClearFormButton(){
        await this.btnClearForm.click();
    }

    async VerifyAllFieldsRequiredMessage(element, warningMessage){
        await expect(element).toHaveText(warningMessage);
    }

    async VerifyRequiredFieldelement(element){      
        //await element.scrollIntoView();  
        await expect((element).nextElement('.invalid-error')).toBeDisplayed();
    }
    async VerifyResultsDisplayed(){
        await expect(this.resultsChart).toBeDisplayed();
    }

    async SelectSocialSecurityIncome(value){
        if(value)
            this.rdbSocialBenifit_Yes.click();
        else
            this.rdbSocialBenifit_No.click();

    }
    async ClickonAdustDefaultValues(){
        await this.linkAdjustDefaultValues.click();
    }
    async VerifyAdditionalSecurityDisplay(){
        if(this.rdbSocialBenifit_Yes.isSelected())
        {
            expect(this.inputSocialSecurityOverrideAmount).toBeDisplayed();
        }
        else
        {            
            expect(this.inputSocialSecurityOverrideAmount.isDisplayed()).toBe(false);
        }
    }
    async VerifyRequiredFields () {
        this.ClickOnCalculateButton();      
        this.VerifyAllFieldsRequiredMessage(this.lblAllRequiredFields, errorMessages.AllFieldsRequired);          
        this.VerifyRequiredFieldelement(this.inputCurrentAge);
        this.VerifyRequiredFieldelement(this.inputRetirementAge);
        this.VerifyRequiredFieldelement(this.inputCurrentIncome);
        this.VerifyRequiredFieldelement(this.inputCurrentRetirementBalance);
        this.VerifyRequiredFieldelement(this.inputCurrentlySaving);
        this.VerifyRequiredFieldelement(this.inputRateOfIncreaseInSavings);
        this.ClickOnClearFormButton();        
    }

    async EnterFormDetails(testData){
        await this.ClickOnClearFormButton();
        await this.EnterCurrentAge(testData.currentAge);
        await this.EnterRetirementAge(testData.retirementAge);
        await this.EnterCurrentAnnaulIncome(testData.currentAnnualIncome);
        await this.EnterSpouseAnnualIncome(testData.spouseAnnualIncome);
        await this.EnterCurrentRetirementSavings(testData.currentRetirementSavings);
        await this.EnterCurrentlySavingEachYear(testData.currentRetirementContribution);
        await this.EnterIncreaseInSavingsEachYear(testData.annualRetirementContributionIncrease);        
        //this.ClickOnCalculateButton();
    }

    /**
     * overwrite specific options to adapt it to page object
     */
    open () {
        return super.open('insights-tools/retirement-calculator.html');
    }
}

module.exports = new RetirementCalculator();
