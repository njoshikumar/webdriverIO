const retirementCalculatorPage = require('../pageobjects/retirementCal.page')
const defaultCalculatorValues = require('../pageobjects/defaultCalculatorValues.page')
const testData = require('../testdata/retirementcalData.json');
const errorMessages = require('../testdata/errorMessages.json');

describe('Retirement Calculator', () => {
    beforeEach(function () {
        retirementCalculatorPage.initialize('insights-tools/retirement-calculator.html');
    });
    afterEach(function () {
        retirementCalculatorPage.initialize('insights-tools/retirement-calculator.html');
    });
    // beforeEach(async () => {
    //     retirementCalculatorPage.initialize('insights-tools/retirement-calculator.html');
    // });
    
    // afterEach(async () => {
    //     retirementCalculatorPage.cleanup();
    // });
    it('Verify Retirement Calculator Required Fields', async () => {
        //await retirementCalculatorPage.open();
        await retirementCalculatorPage.VerifyRequiredFields(testData);              
    })
    it('Verify User can submit the form',async()=>{
        //await retirementCalculatorPage.open();
        browser.pause(2000);
        await retirementCalculatorPage.EnterFormDetails(testData);
        await retirementCalculatorPage.ClickOnCalculateButton();
        await retirementCalculatorPage.VerifyResultsDisplayed();
    })
    it('Verify User should get a warning message if he miss any required field',async ()=>{
        //await retirementCalculatorPage.open();
        await retirementCalculatorPage.ClickOnClearFormButton();
        await retirementCalculatorPage.EnterCurrentAge(testData.currentAge);
        await retirementCalculatorPage.EnterRetirementAge(testData.retirementAge);
        await retirementCalculatorPage.ClickOnCalculateButton();
        await retirementCalculatorPage.VerifyAllFieldsRequiredMessage(retirementCalculatorPage.lblAllRequiredFields, errorMessages.AllFieldsRequired);
        await retirementCalculatorPage.VerifyRequiredFieldelement(retirementCalculatorPage.inputCurrentIncome);
        await retirementCalculatorPage.VerifyRequiredFieldelement(retirementCalculatorPage.inputCurrentRetirementBalance);
        await retirementCalculatorPage.VerifyRequiredFieldelement(retirementCalculatorPage.inputCurrentlySaving);
        await retirementCalculatorPage.VerifyRequiredFieldelement(retirementCalculatorPage.inputRateOfIncreaseInSavings);
    })
    it('Verify Additional Social Security fields should display/hide based on Social Security benefits toggle',async ()=>{
        await retirementCalculatorPage.SelectSocialSecurityIncome(true);
        await retirementCalculatorPage.VerifyAdditionalSecurityDisplay();
        await retirementCalculatorPage.SelectSocialSecurityIncome(false);
        await retirementCalculatorPage.VerifyAdditionalSecurityDisplay();
    })
    it('Verify User can update adjust default values',async ()=>{
         await retirementCalculatorPage.ClickonAdustDefaultValues();
         await defaultCalculatorValues.UpdateDefaultCalculatorValue(testData);
         await defaultCalculatorValues.ClickSaveChanges();
    })
})

